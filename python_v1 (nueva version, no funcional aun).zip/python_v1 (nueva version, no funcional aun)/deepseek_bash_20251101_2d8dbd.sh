cp syncb_config.toml ~/.config/syncb/config.toml
# Editar la configuración según necesidades