git clone <repositorio>
cd syncb